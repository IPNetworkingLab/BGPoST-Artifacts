import typing

import numpy as np
from matplotlib import pyplot as plt


def plot_cdf(times: typing.Iterable, legend: str):
    count1, b_count1 = np.histogram(times, bins=200000)
    pdf1 = count1 / sum(count1)
    cdf1 = np.cumsum(pdf1)
    plt.plot(b_count1[1:], cdf1, label=legend)


def plot_show(x_legend: str):
    plt.ylabel('CDF')
    plt.xlabel(x_legend)
    plt.legend()
    plt.grid()
    plt.show()


if __name__ == '__main__':
    lengths = []
    y = []
    i = 0

    with open("/home/thomas/Bureau/exps/fougasse2/buf_length_2.txt") as f:
        for line in f:
            lengths.append(int(line.strip()))
            y.append(i)
            i += 1


    plt.plot(y, lengths)
    plt.grid()
    plt.show()
