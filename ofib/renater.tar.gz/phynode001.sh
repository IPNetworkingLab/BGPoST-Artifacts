#! /bin/bash -x

if [ "$EUID" -ne 0 ]; then
  echo "Please run as root"
  exit 1
fi


export END_CPU=10
export ROOT=/root
export PYTHON_MINOR_VER=10
export FIRST_SETUP=${ROOT}/first_setup
export TMP=$(mktemp)
if [[ $# != 1 ]] && [[ ! -f $FIRST_SETUP ]]; then
DEBIAN_FRONTEND=noninteractive
sysctl -w net.ipv4.udp_rmem_min=4096000 \
          net.core.rmem_max=26214400 \
          net.core.rmem_default=26214400 \
          net.core.netdev_max_backlog=2000
apt-get update
apt-get autoremove -y
apt-get install software-properties-common curl libevent-dev cargo -y
#add-apt-repository -y ppa:deadsnakes/ppa
apt-get -y install python3."${PYTHON_MINOR_VER}" python3."${PYTHON_MINOR_VER}"-venv htop
python3."${PYTHON_MINOR_VER}" -m ensurepip --default-pip
python3."${PYTHON_MINOR_VER}" -m venv "${ROOT}"/env
source "${ROOT}"/env/bin/activate
pip install --upgrade pip
pip3 install jinja2 --log="${ROOT}/pip1.log"
pip3 install defusedxml --log="${ROOT}/pip2.log"
pip3 install tomli --log="${ROOT}/pip3.log"
pip3 install "${ROOT}"/netutils --log="${ROOT}"/netutils.install.log
#cat "${ROOT}"/roq_key.pub >> "${HOME}"/.ssh/authorized_keys
#mkdir -p /lib/modules/$(uname -r)/misc
#mv "${ROOT}"/vpoll.ko /lib/modules/$(uname -r)/misc
#depmod -a
#modprobe vpoll
#sed -i -e "s/GRUB_CMDLINE_LINUX_DEFAULT=\"\"/GRUB_CMDLINE_LINUX_DEFAULT=\"nosmt isolcpus=0-10\"/g" /etc/default/grub
#update-grub
#mv "${ROOT}"/roq /etc/init.d/
#update-rc.d roq defaults
touch "${FIRST_SETUP}"
reboot
elif [[ $# != 1 ]] && [[ -f "${FIRST_SETUP}" ]]; then
ip netns add node011
ip -n node011 a add fe80::1/64 dev lo
ip -n node011 a add fc00:1:b:: dev lo
ip -n node011 l set dev lo up
ip netns exec node011 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node011 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node011 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node011 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node011 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node012
ip -n node012 a add fe80::1/64 dev lo
ip -n node012 a add fc00:1:c:: dev lo
ip -n node012 l set dev lo up
ip netns exec node012 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node012 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node012 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node012 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node012 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node013
ip -n node013 a add fe80::1/64 dev lo
ip -n node013 a add fc00:1:d:: dev lo
ip -n node013 l set dev lo up
ip netns exec node013 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node013 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node013 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node013 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node013 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node014
ip -n node014 a add fe80::1/64 dev lo
ip -n node014 a add fc00:1:e:: dev lo
ip -n node014 l set dev lo up
ip netns exec node014 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node014 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node014 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node014 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node014 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node015
ip -n node015 a add fe80::1/64 dev lo
ip -n node015 a add fc00:1:f:: dev lo
ip -n node015 l set dev lo up
ip netns exec node015 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node015 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node015 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node015 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node015 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node016
ip -n node016 a add fe80::1/64 dev lo
ip -n node016 a add fc00:1:10:: dev lo
ip -n node016 l set dev lo up
ip netns exec node016 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node016 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node016 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node016 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node016 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node017
ip -n node017 a add fe80::1/64 dev lo
ip -n node017 a add fc00:1:11:: dev lo
ip -n node017 l set dev lo up
ip netns exec node017 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node017 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node017 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node017 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node017 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node018
ip -n node018 a add fe80::1/64 dev lo
ip -n node018 a add fc00:1:12:: dev lo
ip -n node018 l set dev lo up
ip netns exec node018 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node018 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node018 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node018 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node018 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node019
ip -n node019 a add fe80::1/64 dev lo
ip -n node019 a add fc00:1:13:: dev lo
ip -n node019 l set dev lo up
ip netns exec node019 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node019 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node019 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node019 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node019 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node020
ip -n node020 a add fe80::1/64 dev lo
ip -n node020 a add fc00:1:14:: dev lo
ip -n node020 l set dev lo up
ip netns exec node020 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node020 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node020 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node020 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node020 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node021
ip -n node021 a add fe80::1/64 dev lo
ip -n node021 a add fc00:1:15:: dev lo
ip -n node021 l set dev lo up
ip netns exec node021 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node021 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node021 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node021 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node021 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
echo 011_000 | tee -a ${ROOT}/links
ip netns exec node011 bash -c "${ROOT}/delay.sh veth011000 10ms 1000mbit 10ms"
echo 014_000 | tee -a ${ROOT}/links
ip netns exec node014 bash -c "${ROOT}/delay.sh veth014000 10ms 1000mbit 10ms"
echo 011_001 | tee -a ${ROOT}/links
ip netns exec node011 bash -c "${ROOT}/delay.sh veth011001 10ms 1000mbit 10ms"
ip -n node011 l add dev veth011002 type veth peer name veth012000
ip -n node011 l set dev veth012000 netns node012
ip -n node011 l set dev veth011002 up
ip -n node012 l set dev veth012000 up
ip netns exec node011 bash -c "${ROOT}/delay.sh veth011002 10ms 1000mbit 10ms"
ip netns exec node012 bash -c "${ROOT}/delay.sh veth012000 10ms 1000mbit 10ms"
ip -n node011 l add dev veth011003 type veth peer name veth017000
ip -n node011 l set dev veth017000 netns node017
ip -n node011 l set dev veth011003 up
ip -n node017 l set dev veth017000 up
ip netns exec node011 bash -c "${ROOT}/delay.sh veth011003 10ms 1000mbit 10ms"
ip netns exec node017 bash -c "${ROOT}/delay.sh veth017000 10ms 1000mbit 10ms"
ip -n node011 l add dev veth011004 type veth peer name veth019000
ip -n node011 l set dev veth019000 netns node019
ip -n node011 l set dev veth011004 up
ip -n node019 l set dev veth019000 up
ip netns exec node011 bash -c "${ROOT}/delay.sh veth011004 10ms 1000mbit 10ms"
ip netns exec node019 bash -c "${ROOT}/delay.sh veth019000 10ms 1000mbit 10ms"
echo 011_005 | tee -a ${ROOT}/links
ip netns exec node011 bash -c "${ROOT}/delay.sh veth011005 10ms 1000mbit 10ms"
ip -n node011 l add dev veth011006 type veth peer name veth015000
ip -n node011 l set dev veth015000 netns node015
ip -n node011 l set dev veth011006 up
ip -n node015 l set dev veth015000 up
ip netns exec node011 bash -c "${ROOT}/delay.sh veth011006 10ms 1000mbit 10ms"
ip netns exec node015 bash -c "${ROOT}/delay.sh veth015000 10ms 1000mbit 10ms"
echo 011_007 | tee -a ${ROOT}/links
ip netns exec node011 bash -c "${ROOT}/delay.sh veth011007 10ms 1000mbit 10ms"
ip -n node012 l add dev veth012001 type veth peer name veth013000
ip -n node012 l set dev veth013000 netns node013
ip -n node012 l set dev veth012001 up
ip -n node013 l set dev veth013000 up
ip netns exec node012 bash -c "${ROOT}/delay.sh veth012001 10ms 1000mbit 10ms"
ip netns exec node013 bash -c "${ROOT}/delay.sh veth013000 10ms 1000mbit 10ms"
ip -n node013 l add dev veth013001 type veth peer name veth016000
ip -n node013 l set dev veth016000 netns node016
ip -n node013 l set dev veth013001 up
ip -n node016 l set dev veth016000 up
ip netns exec node013 bash -c "${ROOT}/delay.sh veth013001 10ms 1000mbit 10ms"
ip netns exec node016 bash -c "${ROOT}/delay.sh veth016000 10ms 1000mbit 10ms"
ip -n node014 l add dev veth014001 type veth peer name veth015001
ip -n node014 l set dev veth015001 netns node015
ip -n node014 l set dev veth014001 up
ip -n node015 l set dev veth015001 up
ip netns exec node014 bash -c "${ROOT}/delay.sh veth014001 10ms 1000mbit 10ms"
ip netns exec node015 bash -c "${ROOT}/delay.sh veth015001 10ms 1000mbit 10ms"
ip -n node015 l add dev veth015002 type veth peer name veth018000
ip -n node015 l set dev veth018000 netns node018
ip -n node015 l set dev veth015002 up
ip -n node018 l set dev veth018000 up
ip netns exec node015 bash -c "${ROOT}/delay.sh veth015002 10ms 1000mbit 10ms"
ip netns exec node018 bash -c "${ROOT}/delay.sh veth018000 10ms 1000mbit 10ms"
echo 015_003 | tee -a ${ROOT}/links
ip netns exec node015 bash -c "${ROOT}/delay.sh veth015003 10ms 1000mbit 10ms"
echo 016_001 | tee -a ${ROOT}/links
ip netns exec node016 bash -c "${ROOT}/delay.sh veth016001 10ms 1000mbit 10ms"
ip -n node017 l add dev veth017001 type veth peer name veth018001
ip -n node017 l set dev veth018001 netns node018
ip -n node017 l set dev veth017001 up
ip -n node018 l set dev veth018001 up
ip netns exec node017 bash -c "${ROOT}/delay.sh veth017001 10ms 1000mbit 10ms"
ip netns exec node018 bash -c "${ROOT}/delay.sh veth018001 10ms 1000mbit 10ms"
ip -n node017 l add dev veth017002 type veth peer name veth019001
ip -n node017 l set dev veth019001 netns node019
ip -n node017 l set dev veth017002 up
ip -n node019 l set dev veth019001 up
ip netns exec node017 bash -c "${ROOT}/delay.sh veth017002 10ms 1000mbit 10ms"
ip netns exec node019 bash -c "${ROOT}/delay.sh veth019001 10ms 1000mbit 10ms"
echo 018_002 | tee -a ${ROOT}/links
ip netns exec node018 bash -c "${ROOT}/delay.sh veth018002 10ms 1000mbit 10ms"
ip -n node020 l add dev veth020000 type veth peer name veth021000
ip -n node020 l set dev veth021000 netns node021
ip -n node020 l set dev veth020000 up
ip -n node021 l set dev veth021000 up
ip netns exec node020 bash -c "${ROOT}/delay.sh veth020000 10ms 1000mbit 10ms"
ip netns exec node021 bash -c "${ROOT}/delay.sh veth021000 10ms 1000mbit 10ms"
echo 020_001 | tee -a ${ROOT}/links
ip netns exec node020 bash -c "${ROOT}/delay.sh veth020001 10ms 1000mbit 10ms"
echo 021_001 | tee -a ${ROOT}/links
ip netns exec node021 bash -c "${ROOT}/delay.sh veth021001 10ms 1000mbit 10ms"
"${ROOT}"/env/bin/python3 "${ROOT}"/setup.py ${ROOT}/links
ip netns exec node011 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node011 node011 0.0.0.0 ${TMP}"
ip netns exec node012 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node012 node012 0.0.0.0 ${TMP}"
ip netns exec node013 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node013 node013 0.0.0.0 ${TMP}"
ip netns exec node014 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node014 node014 0.0.0.0 ${TMP}"
ip netns exec node015 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node015 node015 0.0.0.0 ${TMP}"
ip netns exec node016 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node016 node016 0.0.0.0 ${TMP}"
ip netns exec node017 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node017 node017 0.0.0.0 ${TMP}"
ip netns exec node018 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node018 node018 0.0.0.0 ${TMP}"
ip netns exec node019 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node019 node019 0.0.0.0 ${TMP}"
ip netns exec node020 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node020 node020 0.0.0.0 ${TMP}"
ip netns exec node021 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node021 node021 0.0.0.0 ${TMP}"
#curl -X POST -H "Content-Type: application/json" -d "{\"topo\": \"579021709b636e877d429e38b593b2a421994116fa1fb246ee0f3112b530a9e3\", \"endpoint\": \"$(cat ${ROOT}/vnode)\"}" https://roq.info.ucl.ac.be:8080/e8b32bc4d7b564ac6075a1418ad8841e/endpoints
else
ip netns exec node011 bash -c "taskset -c 0 "${ROOT}"/bird -s /tmp/node011.bird.sk -c "${ROOT}"/node011.bird.cfg -P /tmp/node011.bird.pid &"
ip netns exec node012 bash -c "taskset -c 1 "${ROOT}"/bird -s /tmp/node012.bird.sk -c "${ROOT}"/node012.bird.cfg -P /tmp/node012.bird.pid &"
ip netns exec node013 bash -c "taskset -c 2 "${ROOT}"/bird -s /tmp/node013.bird.sk -c "${ROOT}"/node013.bird.cfg -P /tmp/node013.bird.pid &"
ip netns exec node014 bash -c "taskset -c 3 "${ROOT}"/bird -s /tmp/node014.bird.sk -c "${ROOT}"/node014.bird.cfg -P /tmp/node014.bird.pid &"
ip netns exec node015 bash -c "taskset -c 4 "${ROOT}"/bird -s /tmp/node015.bird.sk -c "${ROOT}"/node015.bird.cfg -P /tmp/node015.bird.pid &"
ip netns exec node016 bash -c "taskset -c 5 "${ROOT}"/bird -s /tmp/node016.bird.sk -c "${ROOT}"/node016.bird.cfg -P /tmp/node016.bird.pid &"
ip netns exec node017 bash -c "taskset -c 6 "${ROOT}"/bird -s /tmp/node017.bird.sk -c "${ROOT}"/node017.bird.cfg -P /tmp/node017.bird.pid &"
ip netns exec node018 bash -c "taskset -c 7 "${ROOT}"/bird -s /tmp/node018.bird.sk -c "${ROOT}"/node018.bird.cfg -P /tmp/node018.bird.pid &"
ip netns exec node019 bash -c "taskset -c 8 "${ROOT}"/bird -s /tmp/node019.bird.sk -c "${ROOT}"/node019.bird.cfg -P /tmp/node019.bird.pid &"
ip netns exec node020 bash -c "taskset -c 9 "${ROOT}"/bird -s /tmp/node020.bird.sk -c "${ROOT}"/node020.bird.cfg -P /tmp/node020.bird.pid &"
ip netns exec node021 bash -c "taskset -c 10 "${ROOT}"/bird -s /tmp/node021.bird.sk -c "${ROOT}"/node021.bird.cfg -P /tmp/node021.bird.pid &"
fi
