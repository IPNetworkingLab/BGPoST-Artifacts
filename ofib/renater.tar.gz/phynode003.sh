#! /bin/bash -x

if [ "$EUID" -ne 0 ]; then
  echo "Please run as root"
  exit 1
fi


export END_CPU=10
export ROOT=/root
export PYTHON_MINOR_VER=10
export FIRST_SETUP=${ROOT}/first_setup
export TMP=$(mktemp)
if [[ $# != 1 ]] && [[ ! -f $FIRST_SETUP ]]; then
DEBIAN_FRONTEND=noninteractive
sysctl -w net.ipv4.udp_rmem_min=4096000 \
          net.core.rmem_max=26214400 \
          net.core.rmem_default=26214400 \
          net.core.netdev_max_backlog=2000
apt-get update
apt-get autoremove -y
apt-get install software-properties-common curl libevent-dev cargo -y
add-apt-repository -y ppa:deadsnakes/ppa
apt-get -y install python3."${PYTHON_MINOR_VER}" python3."${PYTHON_MINOR_VER}"-venv htop
python3."${PYTHON_MINOR_VER}" -m ensurepip --default-pip
python3."${PYTHON_MINOR_VER}" -m venv "${ROOT}"/env
source "${ROOT}"/env/bin/activate
pip install --upgrade pip
pip3 install jinja2 --log="${ROOT}/pip1.log"
pip3 install defusedxml --log="${ROOT}/pip2.log"
pip3 install tomli --log="${ROOT}/pip3.log"
pip3 install "${ROOT}"/netutils --log="${ROOT}"/netutils.install.log
cat "${ROOT}"/roq_key.pub >> "${HOME}"/.ssh/authorized_keys
mkdir -p /lib/modules/$(uname -r)/misc
mv "${ROOT}"/vpoll.ko /lib/modules/$(uname -r)/misc
depmod -a
modprobe vpoll
sed -i -e "s/GRUB_CMDLINE_LINUX_DEFAULT=\"\"/GRUB_CMDLINE_LINUX_DEFAULT=\"nosmt isolcpus=0-10\"/g" /etc/default/grub
update-grub
mv "${ROOT}"/roq /etc/init.d/
update-rc.d roq defaults
touch "${FIRST_SETUP}"
reboot
elif [[ $# != 1 ]] && [[ -f "${FIRST_SETUP}" ]]; then
ip netns add node033
ip -n node033 a add fe80::1/64 dev lo
ip -n node033 a add fc00:1:21:: dev lo
ip -n node033 l set dev lo up
ip netns exec node033 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node033 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node033 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node033 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node033 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node034
ip -n node034 a add fe80::1/64 dev lo
ip -n node034 a add fc00:1:22:: dev lo
ip -n node034 l set dev lo up
ip netns exec node034 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node034 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node034 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node034 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node034 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node035
ip -n node035 a add fe80::1/64 dev lo
ip -n node035 a add fc00:1:23:: dev lo
ip -n node035 l set dev lo up
ip netns exec node035 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node035 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node035 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node035 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node035 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node036
ip -n node036 a add fe80::1/64 dev lo
ip -n node036 a add fc00:1:24:: dev lo
ip -n node036 l set dev lo up
ip netns exec node036 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node036 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node036 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node036 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node036 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node037
ip -n node037 a add fe80::1/64 dev lo
ip -n node037 a add fc00:1:25:: dev lo
ip -n node037 l set dev lo up
ip netns exec node037 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node037 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node037 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node037 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node037 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node038
ip -n node038 a add fe80::1/64 dev lo
ip -n node038 a add fc00:1:26:: dev lo
ip -n node038 l set dev lo up
ip netns exec node038 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node038 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node038 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node038 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node038 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node039
ip -n node039 a add fe80::1/64 dev lo
ip -n node039 a add fc00:1:27:: dev lo
ip -n node039 l set dev lo up
ip netns exec node039 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node039 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node039 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node039 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node039 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node040
ip -n node040 a add fe80::1/64 dev lo
ip -n node040 a add fc00:1:28:: dev lo
ip -n node040 l set dev lo up
ip netns exec node040 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node040 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node040 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node040 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node040 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
echo 033_000 | tee -a ${ROOT}/links
ip netns exec node033 bash -c "${ROOT}/delay.sh veth033000 10ms 1000mbit 10ms"
echo 034_000 | tee -a ${ROOT}/links
ip netns exec node034 bash -c "${ROOT}/delay.sh veth034000 10ms 1000mbit 10ms"
echo 035_000 | tee -a ${ROOT}/links
ip netns exec node035 bash -c "${ROOT}/delay.sh veth035000 10ms 1000mbit 10ms"
echo 036_000 | tee -a ${ROOT}/links
ip netns exec node036 bash -c "${ROOT}/delay.sh veth036000 10ms 1000mbit 10ms"
echo 037_000 | tee -a ${ROOT}/links
ip netns exec node037 bash -c "${ROOT}/delay.sh veth037000 10ms 1000mbit 10ms"
echo 038_000 | tee -a ${ROOT}/links
ip netns exec node038 bash -c "${ROOT}/delay.sh veth038000 10ms 1000mbit 10ms"
echo 034_001 | tee -a ${ROOT}/links
ip netns exec node034 bash -c "${ROOT}/delay.sh veth034001 10ms 1000mbit 10ms"
echo 039_000 | tee -a ${ROOT}/links
ip netns exec node039 bash -c "${ROOT}/delay.sh veth039000 10ms 1000mbit 10ms"
echo 040_000 | tee -a ${ROOT}/links
ip netns exec node040 bash -c "${ROOT}/delay.sh veth040000 10ms 1000mbit 10ms"
ip -n node035 l add dev veth035001 type veth peer name veth039001
ip -n node035 l set dev veth039001 netns node039
ip -n node035 l set dev veth035001 up
ip -n node039 l set dev veth039001 up
ip netns exec node035 bash -c "${ROOT}/delay.sh veth035001 10ms 1000mbit 10ms"
ip netns exec node039 bash -c "${ROOT}/delay.sh veth039001 10ms 1000mbit 10ms"
ip -n node036 l add dev veth036001 type veth peer name veth037001
ip -n node036 l set dev veth037001 netns node037
ip -n node036 l set dev veth036001 up
ip -n node037 l set dev veth037001 up
ip netns exec node036 bash -c "${ROOT}/delay.sh veth036001 10ms 1000mbit 10ms"
ip netns exec node037 bash -c "${ROOT}/delay.sh veth037001 10ms 1000mbit 10ms"
ip -n node038 l add dev veth038001 type veth peer name veth040001
ip -n node038 l set dev veth040001 netns node040
ip -n node038 l set dev veth038001 up
ip -n node040 l set dev veth040001 up
ip netns exec node038 bash -c "${ROOT}/delay.sh veth038001 10ms 1000mbit 10ms"
ip netns exec node040 bash -c "${ROOT}/delay.sh veth040001 10ms 1000mbit 10ms"
"${ROOT}"/env/bin/python3 "${ROOT}"/setup.py ${ROOT}/links
ip netns exec node033 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node033 node033 0.0.0.0 ${TMP}"
ip netns exec node034 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node034 node034 0.0.0.0 ${TMP}"
ip netns exec node035 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node035 node035 0.0.0.0 ${TMP}"
ip netns exec node036 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node036 node036 0.0.0.0 ${TMP}"
ip netns exec node037 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node037 node037 0.0.0.0 ${TMP}"
ip netns exec node038 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node038 node038 0.0.0.0 ${TMP}"
ip netns exec node039 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node039 node039 0.0.0.0 ${TMP}"
ip netns exec node040 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node040 node040 0.0.0.0 ${TMP}"
curl -X POST -H "Content-Type: application/json" -d "{\"topo\": \"579021709b636e877d429e38b593b2a421994116fa1fb246ee0f3112b530a9e3\", \"endpoint\": \"$(cat ${ROOT}/vnode)\"}" https://roq.info.ucl.ac.be:8080/e8b32bc4d7b564ac6075a1418ad8841e/endpoints
else
ip netns exec node033 bash -c "taskset -c 0 "${ROOT}"/bird -s /tmp/node033.bird.sk -c "${ROOT}"/node033.bird.cfg -P /tmp/node033.bird.pid &"
ip netns exec node034 bash -c "taskset -c 1 "${ROOT}"/bird -s /tmp/node034.bird.sk -c "${ROOT}"/node034.bird.cfg -P /tmp/node034.bird.pid &"
ip netns exec node035 bash -c "taskset -c 2 "${ROOT}"/bird -s /tmp/node035.bird.sk -c "${ROOT}"/node035.bird.cfg -P /tmp/node035.bird.pid &"
ip netns exec node036 bash -c "taskset -c 3 "${ROOT}"/bird -s /tmp/node036.bird.sk -c "${ROOT}"/node036.bird.cfg -P /tmp/node036.bird.pid &"
ip netns exec node037 bash -c "taskset -c 4 "${ROOT}"/bird -s /tmp/node037.bird.sk -c "${ROOT}"/node037.bird.cfg -P /tmp/node037.bird.pid &"
ip netns exec node038 bash -c "taskset -c 5 "${ROOT}"/bird -s /tmp/node038.bird.sk -c "${ROOT}"/node038.bird.cfg -P /tmp/node038.bird.pid &"
ip netns exec node039 bash -c "taskset -c 6 "${ROOT}"/bird -s /tmp/node039.bird.sk -c "${ROOT}"/node039.bird.cfg -P /tmp/node039.bird.pid &"
ip netns exec node040 bash -c "taskset -c 7 "${ROOT}"/bird -s /tmp/node040.bird.sk -c "${ROOT}"/node040.bird.cfg -P /tmp/node040.bird.pid &"
fi
