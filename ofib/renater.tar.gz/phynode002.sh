#! /bin/bash -x

if [ "$EUID" -ne 0 ]; then
  echo "Please run as root"
  exit 1
fi


export END_CPU=10
export ROOT=/root
export PYTHON_MINOR_VER=10
export FIRST_SETUP=${ROOT}/first_setup
export TMP=$(mktemp)
if [[ $# != 1 ]] && [[ ! -f $FIRST_SETUP ]]; then
DEBIAN_FRONTEND=noninteractive
sysctl -w net.ipv4.udp_rmem_min=4096000 \
          net.core.rmem_max=26214400 \
          net.core.rmem_default=26214400 \
          net.core.netdev_max_backlog=2000
apt-get update
apt-get autoremove -y
apt-get install software-properties-common curl libevent-dev cargo -y
#add-apt-repository -y ppa:deadsnakes/ppa
apt-get -y install python3."${PYTHON_MINOR_VER}" python3."${PYTHON_MINOR_VER}"-venv htop
python3."${PYTHON_MINOR_VER}" -m ensurepip --default-pip
python3."${PYTHON_MINOR_VER}" -m venv "${ROOT}"/env
source "${ROOT}"/env/bin/activate
pip install --upgrade pip
pip3 install jinja2 --log="${ROOT}/pip1.log"
pip3 install defusedxml --log="${ROOT}/pip2.log"
pip3 install tomli --log="${ROOT}/pip3.log"
pip3 install "${ROOT}"/netutils --log="${ROOT}"/netutils.install.log
#cat "${ROOT}"/roq_key.pub >> "${HOME}"/.ssh/authorized_keys
#mkdir -p /lib/modules/$(uname -r)/misc
#mv "${ROOT}"/vpoll.ko /lib/modules/$(uname -r)/misc
#depmod -a
#modprobe vpoll
#sed -i -e "s/GRUB_CMDLINE_LINUX_DEFAULT=\"\"/GRUB_CMDLINE_LINUX_DEFAULT=\"nosmt isolcpus=0-10\"/g" /etc/default/grub
#update-grub
#mv "${ROOT}"/roq /etc/init.d/
#update-rc.d roq defaults
touch "${FIRST_SETUP}"
reboot
elif [[ $# != 1 ]] && [[ -f "${FIRST_SETUP}" ]]; then
ip netns add node022
ip -n node022 a add fe80::1/64 dev lo
ip -n node022 a add fc00:1:16:: dev lo
ip -n node022 l set dev lo up
ip netns exec node022 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node022 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node022 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node022 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node022 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node023
ip -n node023 a add fe80::1/64 dev lo
ip -n node023 a add fc00:1:17:: dev lo
ip -n node023 l set dev lo up
ip netns exec node023 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node023 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node023 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node023 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node023 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node024
ip -n node024 a add fe80::1/64 dev lo
ip -n node024 a add fc00:1:18:: dev lo
ip -n node024 l set dev lo up
ip netns exec node024 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node024 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node024 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node024 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node024 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node025
ip -n node025 a add fe80::1/64 dev lo
ip -n node025 a add fc00:1:19:: dev lo
ip -n node025 l set dev lo up
ip netns exec node025 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node025 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node025 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node025 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node025 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node026
ip -n node026 a add fe80::1/64 dev lo
ip -n node026 a add fc00:1:1a:: dev lo
ip -n node026 l set dev lo up
ip netns exec node026 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node026 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node026 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node026 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node026 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node027
ip -n node027 a add fe80::1/64 dev lo
ip -n node027 a add fc00:1:1b:: dev lo
ip -n node027 l set dev lo up
ip netns exec node027 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node027 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node027 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node027 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node027 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node028
ip -n node028 a add fe80::1/64 dev lo
ip -n node028 a add fc00:1:1c:: dev lo
ip -n node028 l set dev lo up
ip netns exec node028 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node028 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node028 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node028 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node028 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node029
ip -n node029 a add fe80::1/64 dev lo
ip -n node029 a add fc00:1:1d:: dev lo
ip -n node029 l set dev lo up
ip netns exec node029 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node029 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node029 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node029 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node029 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node030
ip -n node030 a add fe80::1/64 dev lo
ip -n node030 a add fc00:1:1e:: dev lo
ip -n node030 l set dev lo up
ip netns exec node030 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node030 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node030 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node030 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node030 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node031
ip -n node031 a add fe80::1/64 dev lo
ip -n node031 a add fc00:1:1f:: dev lo
ip -n node031 l set dev lo up
ip netns exec node031 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node031 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node031 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node031 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node031 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
ip netns add node032
ip -n node032 a add fe80::1/64 dev lo
ip -n node032 a add fc00:1:20:: dev lo
ip -n node032 l set dev lo up
ip netns exec node032 bash -c "sysctl -w net.ipv4.ip_forward=1"
ip netns exec node032 bash -c "sysctl -w net.ipv6.conf.all.forwarding=1"
ip netns exec node032 bash -c "sysctl -w net.ipv6.conf.default.keep_addr_on_down=1"
ip netns exec node032 bash -c "sysctl -w net.ipv6.conf.all.keep_addr_on_down=1"
ip netns exec node032 bash -c "sysctl -w net.ipv4.udp_rmem_min=4096000 net.core.rmem_max=26214400 net.core.rmem_default=26214400 net.core.netdev_max_backlog=2000"
echo 026_000 | tee -a ${ROOT}/links
ip netns exec node026 bash -c "${ROOT}/delay.sh veth026000 10ms 1000mbit 10ms"
echo 025_000 | tee -a ${ROOT}/links
ip netns exec node025 bash -c "${ROOT}/delay.sh veth025000 10ms 1000mbit 10ms"
echo 028_000 | tee -a ${ROOT}/links
ip netns exec node028 bash -c "${ROOT}/delay.sh veth028000 10ms 1000mbit 10ms"
echo 029_000 | tee -a ${ROOT}/links
ip netns exec node029 bash -c "${ROOT}/delay.sh veth029000 10ms 1000mbit 10ms"
echo 024_000 | tee -a ${ROOT}/links
ip netns exec node024 bash -c "${ROOT}/delay.sh veth024000 10ms 1000mbit 10ms"
echo 031_000 | tee -a ${ROOT}/links
ip netns exec node031 bash -c "${ROOT}/delay.sh veth031000 10ms 1000mbit 10ms"
echo 032_000 | tee -a ${ROOT}/links
ip netns exec node032 bash -c "${ROOT}/delay.sh veth032000 10ms 1000mbit 10ms"
echo 032_001 | tee -a ${ROOT}/links
ip netns exec node032 bash -c "${ROOT}/delay.sh veth032001 10ms 1000mbit 10ms"
echo 022_000 | tee -a ${ROOT}/links
ip netns exec node022 bash -c "${ROOT}/delay.sh veth022000 10ms 1000mbit 10ms"
echo 028_001 | tee -a ${ROOT}/links
ip netns exec node028 bash -c "${ROOT}/delay.sh veth028001 10ms 1000mbit 10ms"
ip -n node022 l add dev veth022001 type veth peer name veth023000
ip -n node022 l set dev veth023000 netns node023
ip -n node022 l set dev veth022001 up
ip -n node023 l set dev veth023000 up
ip netns exec node022 bash -c "${ROOT}/delay.sh veth022001 10ms 1000mbit 10ms"
ip netns exec node023 bash -c "${ROOT}/delay.sh veth023000 10ms 1000mbit 10ms"
ip -n node023 l add dev veth023001 type veth peer name veth027000
ip -n node023 l set dev veth027000 netns node027
ip -n node023 l set dev veth023001 up
ip -n node027 l set dev veth027000 up
ip netns exec node023 bash -c "${ROOT}/delay.sh veth023001 10ms 1000mbit 10ms"
ip netns exec node027 bash -c "${ROOT}/delay.sh veth027000 10ms 1000mbit 10ms"
ip -n node024 l add dev veth024001 type veth peer name veth025001
ip -n node024 l set dev veth025001 netns node025
ip -n node024 l set dev veth024001 up
ip -n node025 l set dev veth025001 up
ip netns exec node024 bash -c "${ROOT}/delay.sh veth024001 10ms 1000mbit 10ms"
ip netns exec node025 bash -c "${ROOT}/delay.sh veth025001 10ms 1000mbit 10ms"
ip -n node026 l add dev veth026001 type veth peer name veth027001
ip -n node026 l set dev veth027001 netns node027
ip -n node026 l set dev veth026001 up
ip -n node027 l set dev veth027001 up
ip netns exec node026 bash -c "${ROOT}/delay.sh veth026001 10ms 1000mbit 10ms"
ip netns exec node027 bash -c "${ROOT}/delay.sh veth027001 10ms 1000mbit 10ms"
echo 028_002 | tee -a ${ROOT}/links
ip netns exec node028 bash -c "${ROOT}/delay.sh veth028002 10ms 1000mbit 10ms"
ip -n node029 l add dev veth029001 type veth peer name veth030000
ip -n node029 l set dev veth030000 netns node030
ip -n node029 l set dev veth029001 up
ip -n node030 l set dev veth030000 up
ip netns exec node029 bash -c "${ROOT}/delay.sh veth029001 10ms 1000mbit 10ms"
ip netns exec node030 bash -c "${ROOT}/delay.sh veth030000 10ms 1000mbit 10ms"
ip -n node029 l add dev veth029002 type veth peer name veth031001
ip -n node029 l set dev veth031001 netns node031
ip -n node029 l set dev veth029002 up
ip -n node031 l set dev veth031001 up
ip netns exec node029 bash -c "${ROOT}/delay.sh veth029002 10ms 1000mbit 10ms"
ip netns exec node031 bash -c "${ROOT}/delay.sh veth031001 10ms 1000mbit 10ms"
"${ROOT}"/env/bin/python3 "${ROOT}"/setup.py ${ROOT}/links
ip netns exec node022 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node022 node022 0.0.0.0 ${TMP}"
ip netns exec node023 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node023 node023 0.0.0.0 ${TMP}"
ip netns exec node024 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node024 node024 0.0.0.0 ${TMP}"
ip netns exec node025 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node025 node025 0.0.0.0 ${TMP}"
ip netns exec node026 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node026 node026 0.0.0.0 ${TMP}"
ip netns exec node027 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node027 node027 0.0.0.0 ${TMP}"
ip netns exec node028 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node028 node028 0.0.0.0 ${TMP}"
ip netns exec node029 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node029 node029 0.0.0.0 ${TMP}"
ip netns exec node030 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node030 node030 0.0.0.0 ${TMP}"
ip netns exec node031 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node031 node031 0.0.0.0 ${TMP}"
ip netns exec node032 bash -c "sh "${ROOT}"/generate_certs.sh /tmp node032 node032 0.0.0.0 ${TMP}"
#curl -X POST -H "Content-Type: application/json" -d "{\"topo\": \"579021709b636e877d429e38b593b2a421994116fa1fb246ee0f3112b530a9e3\", \"endpoint\": \"$(cat ${ROOT}/vnode)\"}" https://roq.info.ucl.ac.be:8080/e8b32bc4d7b564ac6075a1418ad8841e/endpoints
else
# core 1
IO_QUIC_CORE_ID=0 ip netns exec node022 bash -c "taskset -c 2 "${ROOT}"/bird -s /tmp/node022.bird.sk -c "${ROOT}"/node022.bird.cfg -P /tmp/node022.bird.pid &"
IO_QUIC_CORE_ID=4 ip netns exec node023 bash -c "taskset -c 6 "${ROOT}"/bird -s /tmp/node023.bird.sk -c "${ROOT}"/node023.bird.cfg -P /tmp/node023.bird.pid &"
IO_QUIC_CORE_ID=8 ip netns exec node024 bash -c "taskset -c 10 "${ROOT}"/bird -s /tmp/node024.bird.sk -c "${ROOT}"/node024.bird.cfg -P /tmp/node024.bird.pid &"
IO_QUIC_CORE_ID=12 ip netns exec node025 bash -c "taskset -c 14 "${ROOT}"/bird -s /tmp/node025.bird.sk -c "${ROOT}"/node025.bird.cfg -P /tmp/node025.bird.pid &"
IO_QUIC_CORE_ID=16 ip netns exec node026 bash -c "taskset -c 18 "${ROOT}"/bird -s /tmp/node026.bird.sk -c "${ROOT}"/node026.bird.cfg -P /tmp/node026.bird.pid &"
# core 2
IO_QUIC_CORE_ID=1 ip netns exec node027 bash -c "taskset -c 3 "${ROOT}"/bird -s /tmp/node027.bird.sk -c "${ROOT}"/node027.bird.cfg -P /tmp/node027.bird.pid &"
IO_QUIC_CORE_ID=5 ip netns exec node028 bash -c "taskset -c 7 "${ROOT}"/bird -s /tmp/node028.bird.sk -c "${ROOT}"/node028.bird.cfg -P /tmp/node028.bird.pid &"
IO_QUIC_CORE_ID=9 ip netns exec node029 bash -c "taskset -c 11 "${ROOT}"/bird -s /tmp/node029.bird.sk -c "${ROOT}"/node029.bird.cfg -P /tmp/node029.bird.pid &"
IO_QUIC_CORE_ID=13 ip netns exec node030 bash -c "taskset -c 15 "${ROOT}"/bird -s /tmp/node030.bird.sk -c "${ROOT}"/node030.bird.cfg -P /tmp/node030.bird.pid &"
ip netns exec node031 bash -c "taskset -c 9 "${ROOT}"/bird -s /tmp/node031.bird.sk -c "${ROOT}"/node031.bird.cfg -P /tmp/node031.bird.pid &"
ip netns exec node032 bash -c "taskset -c 10 "${ROOT}"/bird -s /tmp/node032.bird.sk -c "${ROOT}"/node032.bird.cfg -P /tmp/node032.bird.pid &"
fi
